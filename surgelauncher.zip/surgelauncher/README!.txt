Thank you for choosing us!

For fonts to work properly, please open the TrueType file in this folder, and select install. If you do not, you will have a default font and text will be sized weirdly.

If you somehow get the raw menu, the menu is heavily obfuscated, so don't even try to use dnSpy.

https://oculadotnet.github.io/surge/

https://discord.gg/puthere